import time
import math
import machine
led_pin = machine.Pin(25, machine.Pin.OUT)
while True:
  time.sleep(2) # Wait for USB to become ready
  led_pin.toggle()
